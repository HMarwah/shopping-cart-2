import React,{useState} from 'react'
import Highcharts from 'highcharts'
import HighchartsReact from 'highcharts-react-official'
import { Button } from 'antd-v3';


const options = {
  chart: {
    type: 'column'
  },
  title:{
    text:'product visualization'
  },
  xAxis: {
    type: 'category',
    text:'product'
  },
  plotOptions: {
    column: {
        pointPadding:  -0.9,
        borderWidth: 0,
    
    }
  },
  legend:{
     verticalAlign: 'above',
     align:'above'
  },  
  series: [{
    name: 'Duffle-Bag',
    color: 'red',
    data: [{name: 'Duffle-Bag', y: 24916}]
  }, {
    name: 'Travel-pouch',
    color: 'blue',
    data: [{name: 'Travel-pouch', y: 11816}]
  }, {
    name: 'Duffle-plates',
    color: 'orange', 
    data: [{name: 'Duffle-plates', y: 34400}]
  }, {
    name: 'Duffle-bag',
    color: 'green', 
    data: [{name: 'Duffle-bag', y: 12908}]
  },
 ]
}

function BarChart() {
    const [isModalVisible, setIsModalVisible] = useState(false);

    const handleOk = () => {
        setIsModalVisible(false);
      };
    
    return <div>
        <HighchartsReact highcharts={Highcharts} options={options} button={Button}/>
    
    </div>
}

export default BarChart